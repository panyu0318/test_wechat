Page({
  data:{
    weeklyMovieList:[
      {
        name: "超时空同居",
        comment: "失去的才是永恒的",
        imagePath: "/images/head1.png",
        isHighlyRecommended: true,
        id: 27133303
      },
      {
        name: "复仇者联盟3：无限战争",
        comment: "最精彩的剧本",
        imagePath: "/images/head2.png",
        isHighlyRecommended: false,
        id: 24773958
      },
      {
        name: "完美陌生人",
        comment: "最精彩的剧本",
        imagePath: "/images/head3.png",
        isHighlyRecommended: true,
        id: 26614893
      }
    ],
    currentIndex:0
  },
  onLoad:function(options){
    this.setData({
      currentIndex: this.data.weeklyMovieList.length-1
    })
  },
  f0:function(event){
    this.setData({
      currentIndex: this.data.weeklyMovieList.length - 1
    })
  },
  f1:function(event){
    var movieId = event.currentTarget.dataset.movieId;
    console.log(movieId);
    wx.navigateTo({
      url: '/pages/detail/detail?id='+movieId
    })
  },
  onShareAppMessage:function(){
    return{
      title:"每周推荐"
    }
  }
})